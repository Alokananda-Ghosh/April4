package com.cg.query.dao;



import com.cg.query.bean.query_master;
import com.cg.query.exception.QueryException;

public interface IQueryDAO {
public query_master getAll(int id) throws QueryException;
}
