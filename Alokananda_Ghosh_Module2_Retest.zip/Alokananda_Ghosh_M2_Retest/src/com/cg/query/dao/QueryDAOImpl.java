package com.cg.query.dao;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.springframework.stereotype.Repository;


import com.cg.query.bean.query_master;

@Repository
public class QueryDAOImpl implements IQueryDAO{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public query_master getAll(int id) {
		// TODO Auto-generated method stub
		//Fetching the value from the database according to the id
		query_master query_master_value = entityManager.find(query_master.class, id);
		return query_master_value;
	}
	
	
}
