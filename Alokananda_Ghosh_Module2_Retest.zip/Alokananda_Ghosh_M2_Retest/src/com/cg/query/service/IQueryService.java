package com.cg.query.service;



import com.cg.query.bean.query_master;
import com.cg.query.exception.QueryException;

public interface IQueryService {
	public query_master getAll(int id) throws QueryException;
}
