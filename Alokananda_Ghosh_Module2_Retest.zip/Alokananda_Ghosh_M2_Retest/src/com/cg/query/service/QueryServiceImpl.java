package com.cg.query.service;



import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.query.bean.query_master;
import com.cg.query.dao.IQueryDAO;
@Service
@Transactional
public class QueryServiceImpl implements IQueryService {
	@Autowired
	IQueryDAO iqd;
	//Taking getter-setter of the dao reference
	public IQueryDAO getIqd() {
		return iqd;
	}
	public void setIqd(IQueryDAO iqd) {
		this.iqd = iqd;
	}
	@Override
	public query_master getAll(int id) {
		// TODO Auto-generated method stub
		return iqd.getAll(id);
	}

}
