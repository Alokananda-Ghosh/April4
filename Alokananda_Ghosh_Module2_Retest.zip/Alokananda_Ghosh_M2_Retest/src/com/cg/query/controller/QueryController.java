package com.cg.query.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.query.bean.query_master;
import com.cg.query.service.IQueryService;

@Controller
public class QueryController {
	@Autowired
	IQueryService iqs;

	public IQueryService getIqs() {
		return iqs;
	}

	public void setIqs(IQueryService iqs) {
		this.iqs = iqs;
	}

	@RequestMapping("/menu")
	public String menu() {
		return "menu";
	}

	@RequestMapping("/Show")
	public ModelAndView show(@RequestParam("id") int id, Model m) {
		query_master query_master_value = iqs.getAll(id);
		if(query_master_value!=null) {
			//If query_master object is not null then it will navigate to  ShowPage to show the values
			return new ModelAndView("ShowPage", "query_master_value", query_master_value);
		}
		//If no query_master object came.Then Failure page will be navigated
		return new ModelAndView("Failure", "id", id);
		
		
	}
	@RequestMapping("/Success")
	public ModelAndView success(@RequestParam("id") int id, Model m) {
		return new ModelAndView("Success", "id", id);
		
	}
}
